<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class customeParking extends Model
{
    //
}
