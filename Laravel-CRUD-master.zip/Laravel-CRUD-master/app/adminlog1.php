<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adminlog1 extends Model
{
    //
    public function login(Request $req)
    {

    }
}
